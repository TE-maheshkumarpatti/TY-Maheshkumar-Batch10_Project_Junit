package com.te.junit.mathutil;

public class MathUtil {

   public int addNumbers(int a, int b)
   {
	   return a+b;
   }
   
   public int dividing(int a, int b)
   {
	   return a/b;
   }

}
